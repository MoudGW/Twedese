<!DOCTYPE html>
<html lang="fr">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : "Accueil"); ?></title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=992" />
		<meta name="description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta name="keywords" content="<?php echo htmlspecialchars(($seoKeywords !== "") ? $seoKeywords : ""); ?>" />
		<!-- Facebook Open Graph -->
	<meta property="og:title" content="<?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : "Accueil"); ?>" />
	<meta property="og:description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta property="og:image" content="<?php echo htmlspecialchars(($seoImage !== "") ? "{{base_url}}".$seoImage : ""); ?>" />
	<meta property="og:type" content="article" />
	<meta property="og:url" content="{{curr_url}}" />
	<!-- Facebook Open Graph end -->
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js?v=20200507092306" type="text/javascript"></script>

	<link href="css/font-awesome/font-awesome.min.css?v=4.7.0" rel="stylesheet" type="text/css" />
	<link href="css/site.css?v=20200713160422" rel="stylesheet" type="text/css" id="wb-site-stylesheet" />
	<link href="css/common.css?ts=1595012054" rel="stylesheet" type="text/css" />
	<link href="css/1.css?ts=1595012054" rel="stylesheet" type="text/css" id="wb-page-stylesheet" />
	<script src="js/jquery.browser.min.js" type="text/javascript"></script>
	<link href="js/photoswipe/photoswipe.css" rel="stylesheet" type="text/css" />
	<link href="js/photoswipe/default-skin/default-skin.css" rel="stylesheet" type="text/css" />
	<script src="js/photoswipe/photoswipe.min.js" type="text/javascript"></script>
	<script src="js/photoswipe/photoswipe-ui-default.min.js" type="text/javascript"></script>
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
</script>
	
	<link href="css/flag-icon-css/css/flag-icon.min.css" rel="stylesheet" type="text/css" />	
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

	</head>


<body class="site <?php if (isset($wbPopupMode) && $wbPopupMode) echo ' popup-mode'; ?> " <?php if (isset($wbLandingPage) && $wbLandingPage) echo ' data-landing-page="'.$wbLandingPage.'"'; ?>><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div class="wb_cont_inner"><div id="wb_element_instance0" class="wb_element wb-menu"><ul class="hmenu"><li class="active"><a href="" target="_self">Accueil</a></li><li><a href="Nos-circuits/" target="_self">Nos circuits</a></li><li><a href="Festival/" target="_self">Festival </a></li><li><a href="Contacts/" target="_self">Contacts</a></li></ul><div class="clearfix"></div></div><div id="wb_element_instance1" class="wb_element wb_text_element" style=" line-height: normal;"><h4 class="wb-stl-pagetitle" style="text-align: center;"><span style="color:rgba(255,189,48,1);">TEWDEST <span style="color:rgba(13,13,12,1);">les Auberges du desert</span></span></h4>
</div></div><div class="wb_cont_outer"><div id="wb_element_instance2" class="wb_element wb_gallery"><script type="text/javascript" src="js/WB_Gallery.class.js?v=20200710111616"></script><script type="text/javascript">
			$(function() {
				new WB_Gallery({"id":"wb_element_instance2","type":"slideshow","interval":3,"speed":400,"fullWidth":true,"imageCover":true,"disablePopup":false,"width":1007,"height":100,"border":{"differ":false,"color":["#00008c","#ffffff","#ffffff","#f0659c"],"style":["none","none","none","none"],"weight":[5,5,5,5],"radius":null,"css":{"border":"5px none #00008c"},"cssRaw":"border: 5px none #00008c;"},"borderWidths":[0,0,0,0],"padding":0,"thumbWidth":100,"thumbHeight":100,"columnWidth":106,"rowHeight":106,"thumbAlign":"center","thumbPadding":6,"thumbOpacity":100,"showPictureCaption":"always","images":[{"thumb":"gallery_gen\/3d00004e120d6680d33a1afd373f7681_100x100.jpg","image":"gallery_gen\/54b3d8c5936dd750be53663dc8314bee.jpg","width":1152,"height":768,"title":"SUR LES TRACES DES ANC\u00caTRES                    OCTOBRE 2020","link":null,"description":"LE FESTIVAL DE LA D\u00c9CENNIE "},{"thumb":"gallery_gen\/4e846433facc0e74394015b01af604ac_100x100.jpg","image":"gallery_gen\/e35e0c019b42056a42cd5edd6c310847.jpg","width":1000,"height":562,"title":"CULTURELLE                       ","link":null,"description":"Lebjawi , Er\u2019hil Levrigh ,Tissage Confection  des  Guerba , Medh ,                                                       "},{"thumb":"gallery_gen\/cbf5f229339a8eff2d155a8935c4b296_100x100.jpg","image":"gallery_gen\/86cd07269e57cfe4108f5fcb4bfb37d0.jpg","width":620,"height":400,"title":"TOURISTIQUE                        ","link":null,"description":"Course des Chameaux, Tir \u00e0 la  cible, Sigue,Ikrour , Talbat, Marathon \u00e0 pieds Cyclisme Maquillage traditionnel.  "},{"thumb":"gallery_gen\/f4698c0576f2c8071eea6bbfe349436c_100x100.jpeg","image":"gallery_gen\/cdf51eb9e25d035147071c9b3ac8119f.jpeg","width":636,"height":422,"title":"ENVIRONNEMENTALE                ","link":null,"description":"Sensibilisation  sur la protection de  l\u2019environnement."},{"thumb":"gallery_gen\/d3fc0ca2d44ae57ac7aac6977132eab2_100x100.JPG","image":"gallery_gen\/c9aa545f35e00d6c90785f0deeddd39a.JPG","width":1920,"height":1080,"title":"TEWDEST","link":null,"description":""}]});
			});
		</script></div></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div class="wb_cont_inner"><div id="wb_element_instance15" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-custom1" style="text-align: center;"><span style="color:rgba(255,189,48,1);">Voyageons !</span></p>

<h5 class="wb-stl-subtitle" style="text-align: center;"><strong><span style="color:rgba(255,255,255,1);">Échappez vous au paradis</span></strong></h5>

<p> </p>

<p style="text-align: center;"><span style="color:rgba(250,249,247,1);"><strong>Paysages insolites et désertiques, véritable composition géologique, l’ensemble de ses territoires relie les ergs aux massifs de montagnes, les plateaux brûlés par le soleil des siècles aux larges et profonds canyons, les verdoyantes oasis et palmeraies aux dunes de sables et campements nomades, sans  oublier  les impressionnantes  passes et les peintures rupestres. Au milieu de ce cocktail de paysages se situe l’auberge de TEWDEST, lieu du festival, au dessus de la passe de TOURFINE, carrefour entre cette variété de paysages unique au monde et les villes anciennes de Chinguitty et Ouadane .  L’auberge de TEWDEST offre tout le confort souhaitée : des bungalows , des cases et des khaimas bien équipés pour l’hébergement, un restaurant-bar moderne avec wifi et télévision ,un bloc sanitaire propre et hygiénique au milieu de palmiers dattiers , d’arbres et de verdure ,traversée par une source d’eau ,milieu favorable pour le repos et la méditation , une vraie écologie dans le désert. Auberge bien éclairée par l’énergie solaire .Proposant aux voyageurs plusieurs activités : balade à dos de chameau, soirée d’observation des étoiles, visite des oasis et palmeraies, randonnée en VTT …</strong></span></p>
</div><div id="wb_element_instance16" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-custom1" style="text-align: center;"><span style="color:rgba(255,189,48,1);">Voyageons !</span></p>

<h1 class="wb-stl-heading1" style="text-align: center;"><a href="https://earth.google.com/web/search/20%c2%b004%2730%22N+13%c2%b005%2702%22W/@20.075,-13.0838889,245.96623521a,985.12306821d,35y,161.57520929h,45t,0r/data=CigiJgokCUXAzUorGjJAEUv2_DMrGTJAGSaERNw69C_AIWE-DLat9y_A" target="_blank"><strong><span style="color:rgba(0,0,0,1);">Teneguev Oasis de rêve</span></strong></a></h1>

<p> </p>

<p>A la croisée des chemins entre les pays du Maghreb et l’Afrique, notre pays fascine par  la diversité de ses paysages, la douceur de son climat et son hospitalité légendaire. Authentique dans ses traditions, ouvert sur la modernité, le pays d’un million de poètes est une invitation perpétuelle au dépaysement  et à la découverte d’un patrimoine culturel et artistique d’une infinie richesse, c’est aussi et surtout une mosaïque géographique unique au monde. Des reliefs de l’Adrar jusqu’à la cote atlantique en passant par des vallées verdoyantes, des cités majestueuses et des oasis. La Mauritanie toute entière vibre aux couleurs d’une nature généreuse et d’un peuple tout aussi accueillant.</p>
</div><div id="wb_element_instance17" class="wb_element"><a class="wb_button" href="Festival/"><span>les plateaux brûlés par le soleil des siècles</span></a></div><div id="wb_element_instance18" class="wb_element"><a class="wb_button" href="Festival/"><span>les ergs au massifs de montagne</span></a></div><div id="wb_element_instance19" class="wb_element"><a class="wb_button" href="Festival/"><span></span></a></div><div id="wb_element_instance20" class="wb_element"><a class="wb_button" href="Festival/"><span></span></a></div><div id="wb_element_instance21" class="wb_element"><a class="wb_button" href="Festival/"><span></span></a></div><div id="wb_element_instance22" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-custom1" style="text-align: center;"><span style="color:rgba(255,189,48,1);">Voyageons !</span></p>

<h1 class="wb-stl-heading1" style="text-align: center;"><span style="color:rgba(255,255,255,1);"><strong>Voyage éxotique</strong></span></h1>

<p> </p>

<p class="wb-stl-normal" style="text-align: center;"> </p>

<p class="wb-stl-normal" style="text-align: center;"><span style="color:rgba(255,255,255,1);">Notre agence propose des circuits qui vous permettrons de découvrir la diversité des paysages désertiques de notre pays à travers une variété de circuits, decouvrez les divers millieux naturels preservé en Mauritanie, vivre l'immensité du desert, vous vous emmerveillerez devant des  manuscrits anciens, vous traverserez des paysages insolites et désertiques avec des dunes de sable parsemmées de verdoyantes oasis, vous observeréz des banc d'oiseaux migrateurs.</span></p>
</div><div id="wb_element_instance23" class="wb_element wb_element_picture" title=""><img alt="gallery/WhatsApp Image 2020-06-17 at 22.52.54" src="gallery_gen/36994b5febcaa23af15bd05d813a4ba6_418x332.jpeg"></div><div id="wb_element_instance24" class="wb_element wb_element_picture" title=""><i class="fa fa-camera" style="color:#000000"></i></div><div id="wb_element_instance25" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-normal">T</p>
</div><div id="wb_element_instance26" class="wb_element wb_element_picture" title=""><i class="fa fa-plane" style="color:#000000"></i></div><div id="wb_element_instance27" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-normal">T.</p>
</div><div id="wb_element_instance28" class="wb_element wb_element_picture" title=""><i class="fa fa-cutlery" style="color:#000000"></i></div><div id="wb_element_instance29" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-normal">T</p>
</div><div id="wb_element_instance30" class="wb_element wb_element_picture" title=""><i class="fa fa-hotel" style="color:#000000"></i></div><div id="wb_element_instance31" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-normal">T</p>
</div><div id="wb_element_instance32" class="wb_element wb_element_picture" title=""><img alt="gallery/81670186_2329084580529599_968039951541207040_n" src="gallery_gen/70cedc7c8636af1af6a2dae1296a069d_320x181.jpg"></div><div id="wb_element_instance33" class="wb_element wb_element_picture" title=""><img alt="gallery/WhatsApp Image 2020-06-18 at 14.56.34" src="gallery_gen/9be0625926c3527d4281482995e8e625_320x181.jpeg"></div><div id="wb_element_instance34" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2" style="text-align: center;"><a href="https://earth.google.com/web/search/Auberge+Tewdest+Nouakchott,+Nouakchott,+Mauritanie/@18.10069405,-15.98103303,5.04672578a,257.40902783d,35y,162.65623789h,44.99528909t,0r/data=CpwBGnISbAokMHhlOTY0ZGI4YTM5NGI3M2Q6MHgxM2U5MTIwMjQwNGJiMGFhGeIEptO6GTJAIQUoV8Ik9i_AKjJBdWJlcmdlIFRld2Rlc3QgTm91YWtjaG90dCwgTm91YWtjaG90dCwgTWF1cml0YW5pZRgCIAEiJgokCc29nAH5dzpAEcq9nAH5dzrAGVMZMbS0yUHAISY1X8LPHGLA" target="_blank">Auberge tewdest Nouakchott </a></h2>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong>11 chambres 15 à 30 € </strong></span></p>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong>Bar Resto</strong></span></p>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong>Wifi</strong></span></p>

<p> </p>
</div><div id="wb_element_instance35" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2" style="text-align: center;"><strong><a href="https://earth.google.com/web/search/20.178215,+-13.045598/@20.17832075,-13.04510769,330.16098784a,454.75075739d,35y,-45.61455815h,44.99742489t,0r/data=ClkaLxIpGRmojH-fLTRAIamG_Z5YFyrAKhUyMC4xNzgyMTUsIC0xMy4wNDU1OTgYAiABIiYKJAkPR6spqkU0QBEJ4FxQVRc0QBk_fO_7XrEpwCFzm37b2R0qwA" target="_blank">Auberge tewdest Adrar</a><a href="http://" target="_blank"> </a></strong></h2>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong>Capacité 200 personnes</strong></span></p>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong>Hebergement penssion complete 20 </strong></span><span style="color:rgba(240,175,12,1);"><strong>€</strong></span></p>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong> Resto menu diversifié</strong></span></p>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong>Eau chaude</strong></span></p>

<p style="text-align: center;"><font color="#e68a19"><b>Chamelier / Chameaux 12 </b></font><span style="color:rgba(224,145,9,1);"><strong>€</strong></span></p>

<p style="text-align: center;"> </p>

<p> </p>
</div><div id="wb_element_instance36" class="wb_element wb_element_picture" title=""><img alt="gallery/20150808_162847" src="gallery_gen/6b5ca6ec20d7133a0650d9b1acedccd2_320x181.jpg"></div><div id="wb_element_instance37" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2" style="text-align: center;"><span class="wb-stl-custom11"><a href="https://earth.google.com/web/search/20%c2%b004%2730%22N+13%c2%b005%2702%22W/@20.075,-13.0838889,245.96623521a,985.12306821d,35y,161.57520929h,45t,0r/data=CigiJgokCUXAzUorGjJAEUv2_DMrGTJAGSaERNw69C_AIWE-DLat9y_A" target="_blank"><span style="color:rgba(13,13,13,1);">Auberge tewdest Teneguev </span></a></span></h2>

<h5 class="wb-stl-custom13" style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong>Capacité 200 personnes</strong></span></h5>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong>Hebergement penssion complete 20 €</strong></span></p>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong> Resto menu</strong></span><span style="color:rgba(230,138,25,1);"><strong> diversifié</strong></span></p>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong>Eau chaude</strong></span></p>

<p style="text-align: center;"><span style="color:rgba(230,138,25,1);"><strong>Ch</strong></span><span style="color:rgba(230,138,25,1);"><strong>amelier / Chameaux 12 €</strong></span></p>
</div><div id="wb_element_instance38" class="wb_element wb_element_shape"><a class="wb_shp"></a></div><div id="wb_element_instance39" class="wb_element wb_text_element" style=" line-height: normal;"><h4 class="wb-stl-custom14"><a href="Contacts/">Réservez</a></h4>
</div><div id="wb_element_instance40" class="wb_element wb_text_element" style=" line-height: normal;"><h4 class="wb-stl-custom14"><a href="Contacts/">Réservez</a></h4>
</div><div id="wb_element_instance41" class="wb_element wb_text_element" style=" line-height: normal;"><h4 class="wb-stl-custom14"><a href="Contacts/">Réservez</a></h4>
</div><div id="wb_element_instance42" class="wb_element wb_text_element" style=" line-height: normal;"><h2 class="wb-stl-heading2"><strong>Visites inoubliables</strong></h2>

<p> </p>

<p class="wb-stl-normal">Carrefour entre cette vallée de paysage unique au monde et les villes anciennes de Chinguitty et Ouadane.Voyageant seul, en famille ou en groupe, choisissez le calme dans l'une de nos auberges TEWDEST et TENEGUEV au coeur de l'Adrar </p>
</div><div id="wb_element_instance43" class="wb_element wb_element_shape"><a class="wb_shp"></a></div><div id="wb_element_instance44" class="wb_element wb_element_shape"><a href="Contacts/" class="wb_shp"></a></div></div><div class="wb_cont_outer"><div id="wb_element_instance45" class="wb_element wb_gallery"><script type="text/javascript" src="js/WB_Gallery.class.js?v=20200710111616"></script><script type="text/javascript">
			$(function() {
				new WB_Gallery({"id":"wb_element_instance45","type":"slideshow","interval":3,"speed":400,"fullWidth":true,"imageCover":true,"disablePopup":false,"width":1007,"height":550,"border":{"differ":false,"color":["#00008c","#ffffff","#ffffff","#ffffff"],"style":["none","none","none","none"],"weight":[5,5,5,5],"radius":null,"css":{"border":"5px none #00008c"},"cssRaw":"border: 5px none #00008c;"},"borderWidths":[0,0,0,0],"padding":0,"thumbWidth":290,"thumbHeight":290,"columnWidth":296,"rowHeight":296,"thumbAlign":"center","thumbPadding":6,"thumbOpacity":60,"showPictureCaption":"always","images":[{"thumb":"gallery_gen\/16607f2a464c159078941fc74a27be9a_290x290.jpg","image":"gallery_gen\/e3ab17781bbc05fe9ed53d6e1660a455.jpg","width":1152,"height":768,"title":"","link":null,"description":""},{"thumb":"gallery_gen\/b94dce1470a5ac6c38c5bafc4d71fd9c_290x290.jpg","image":"gallery_gen\/2c73ed011dc6af46433614c0b640d8d6.jpg","width":1152,"height":768,"title":"","link":null,"description":""},{"thumb":"gallery_gen\/aee1ac1170e41c555a066bfea83c70aa_290x290.jpg","image":"gallery_gen\/448e3c22143225a8043a1aefde19cfc6.jpg","width":1152,"height":768,"title":"","link":null,"description":""},{"thumb":"gallery_gen\/bc47af80df3896484f88681b8cbb2550_290x290.jpg","image":"gallery_gen\/21bdff63634214b5d3520283ec5b631e.jpg","width":1280,"height":402,"title":"","link":null,"description":""},{"thumb":"gallery_gen\/b5084f23eda5a19335a6ed0c2219e45b_290x290.jpg","image":"gallery_gen\/a912b86574fdb6d71a591fd35994e8dd.jpg","width":1152,"height":768,"title":"","link":null,"description":""},{"thumb":"gallery_gen\/7fe3e7972e88d7ca08af452244728931_290x290.jpg","image":"gallery_gen\/4b7f0d2ff4a2d647f359f9e74f42dfe7.jpg","width":1152,"height":768,"title":"","link":null,"description":""},{"thumb":"gallery_gen\/b4a85a63f63f70292126c17e1a2cd6ed_290x290.jpg","image":"gallery_gen\/ddde861475d2c576b666b786af7bd349.jpg","width":1152,"height":768,"title":"","link":null,"description":""}]});
			});
		</script></div><div id="wb_element_instance46" class="wb_element wb_element_shape"><a class="wb_shp"></a></div></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_footer">
	
<div class="wb_cont_inner" style="height: 316px;"><div id="wb_element_instance3" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-footer">© 2020 <a href="http://tewdest.com">tewdest.com</a></p></div><div id="wb_element_instance4" class="wb_element wb_element_picture" title=""><a href="https://www.lws.fr/" target="_blank"><img alt="gallery/08c5d21324732a689558a0b60a0ef3b4.lock" src="gallery_gen/3a6850ebafa9683e2edb4ce0102e793f_113x46.png"></a></div><div id="wb_element_instance5" class="wb_element wb_element_picture" title=""><a href="https://web.facebook.com/lesaubergestewdest.lofficiel" target="_blank"><i class="fa fa-facebook-f" style="color:#ffffff"></i></a></div><div id="wb_element_instance6" class="wb_element wb_element_picture" title=""><a href="https://twitter.com/home" target="_blank"><i class="fa fa-twitter" style="color:#ffffff"></i></a></div><div id="wb_element_instance7" class="wb_element wb_element_picture" title=""><a href="https://www.linkedin.com/feed/?trk=onboarding-landing" target="_blank"><i class="fa fa-linkedin" style="color:#ffffff"></i></a></div><div id="wb_element_instance8" class="wb_element wb_element_picture" title=""><i class="fa fa-phone" style="color:#ffffff"></i></div><div id="wb_element_instance9" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-footer"><span style="color:rgba(255,255,255,1);">Tél. :</span></p>

<p class="wb-stl-footer"><span style="color:rgba(255,255,255,1);">+ 222  45 29 80 31</span></p>

<p class="wb-stl-footer"><span style="color:rgba(255,255,255,1);"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;">+ 222 27 26 89 99</span></span></span></span></span></span></span></span></span></p>

<p class="wb-stl-footer"><span style="color:rgba(255,255,255,1);"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;"><span dir="ltr" style="direction: ltr;">+ 222 41 44 52 23</span></span></span></span></span></span></span></span></span></p>

<p class="wb-stl-footer"><span style="color:rgba(255,255,255,1);">Courriel:info@tewdest.com</span></p>
</div><div id="wb_element_instance10" class="wb_element wb_element_picture" title=""><i class="fa fa-map-marker" style="color:#ffffff"></i></div><div id="wb_element_instance11" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-footer"><span style="color:rgba(255,255,255,1);">Adresse:ZRA N°0216 RDC TVZ</span></p>

<p class="wb-stl-footer"><span style="color:rgba(255,255,255,1);">NOUAKCHOTT - MAURITANIE</span></p>

<p class="wb-stl-footer"> </p>
</div><div id="wb_element_instance12" class="wb_element"><form class="wb_form" method="post" enctype="multipart/form-data"><input type="hidden" name="wb_form_id" value="b6ae55eb"><textarea name="message" rows="3" cols="20" class="hpc" autocomplete="off"></textarea><table><tr><th class="wb-stl-footer">E-mail&nbsp;&nbsp;</th><td><input type="hidden" name="wb_input_0" value="E-mail"><input class="form-control form-field" type="text" value="" name="wb_input_0" required="required"></td></tr><tr class="form-footer"><td colspan="2"><button type="submit" class="btn btn-default">Soumettre</button></td></tr></table><?php if (isset($wbPopupMode) && $wbPopupMode): ?><input type="hidden" name="wb_popup_mode" value="1" /><?php endif; ?></form><script type="text/javascript">
			<?php $wb_form_id = popSessionOrGlobalVar("wb_form_id"); if ($wb_form_id == "b6ae55eb") { ?>
				<?php $wb_form_send_success = popSessionOrGlobalVar("wb_form_send_success"); ?>
				var formValues = <?php echo json_encode(popSessionOrGlobalVar("post")); ?>;
				var formErrors = <?php echo json_encode(popSessionOrGlobalVar("formErrors")); ?>;
				wb_form_validateForm("b6ae55eb", formValues, formErrors);
				<?php if (($wb_form_send_state = popSessionOrGlobalVar("wb_form_send_state"))) { ?>
					<?php if (($wb_form_popup_mode = popSessionOrGlobalVar("wb_form_popup_mode"))) { ?>
					if (window !== window.parent && window.parent.postMessage) {
						var data = {
							event: "wb_contact_form_sent",
							data: {
								state: "<?php echo str_replace('"', '\"', $wb_form_send_state); ?>",
								type: "<?php echo $wb_form_send_success ? "success" : "danger"; ?>"
							}
						};
						window.parent.postMessage(data, "<?php echo str_replace('"', '\"', popSessionOrGlobalVar("wb_target_origin")); ?>");
					}
					<?php } else { ?>
					wb_show_alert("<?php echo str_replace(array('"', "\r", "\n"), array('\"', "", "<br/>"), $wb_form_send_state); ?>", "<?php echo $wb_form_send_success ? "success" : "danger"; ?>");
					<?php } ?>
					<?php $wb_form_send_success = false; $wb_form_send_state = null; $wb_form_popup_mode = false; ?>
				<?php } ?>
			<?php } ?>
			</script></div><div id="wb_element_instance13" class="wb_element wb_text_element" style=" line-height: normal;"></div><div id="wb_element_instance14" class="wb_element wb_text_element" style=" line-height: normal;"><p class="wb-stl-footer"><span style="color:rgba(255,255,255,1);"><strong>Soyez sociable</strong></span></p></div><div id="wb_element_instance48" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer, #wb_footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div><div class="wb_cont_outer"><div id="wb_element_instance47" class="wb_element wb_element_shape"><div class="wb_shp"></div></div></div><div class="wb_cont_bg"></div></div><div class="wb_sbg"></div></div>
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="pswp__bg" style="opacity: 0.7;"></div>
	<div class="pswp__scroll-wrap">
		<div class="pswp__container">
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
		</div>
		<div class="pswp__ui pswp__ui--hidden">
			<div class="pswp__top-bar">
				<div class="pswp__counter"></div>
				<button class="pswp__button pswp__button--close" title="Fermer"></button>
				<button class="pswp__button pswp__button--zoom" title="Zoom avant/arrière"></button>
				<div class="pswp__preloader">
					<div class="pswp__preloader__icn">
						<div class="pswp__preloader__cut">
							<div class="pswp__preloader__donut"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
				<div class="pswp__share-tooltip"></div> 
			</div>
			<button class="pswp__button pswp__button--arrow--left" title="Précédent"></button>
			<button class="pswp__button pswp__button--arrow--right" title="Suivant"></button>
			<div class="pswp__caption"><div class="pswp__caption__center"></div></div>
		</div>
	</div>
</div>
{{hr_out}}</body>
</html>
